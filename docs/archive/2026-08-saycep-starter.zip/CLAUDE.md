# SAYCEP — SA Youth Career and Employment Platform

## What this is

A free, AI-assisted web platform giving South African youth a personalised career
roadmap and matching them to opportunities that suit their actual situation.

Two user profiles drive every design decision:

- **Student** — already enrolled in a qualification. Needs internships suited to
  their year level, certifications to work toward, workshops, industry events.
- **Unqualified user** — no qualification, no direction. Needs interest and
  strength assessment first, then a concrete route: which TVET college, which
  SETA apprenticeship, what the entry requirements are.

If a feature does not serve one of these two profiles, it is out of scope.

This is a solo final-year academic project. It is assessed on a fixed deadline
(30 November 2026) and on evidence, not on polish. A working, demonstrable,
tested slice always beats an elegant half-finished one.

## Who I am

Solo developer. Background is business analysis and project management, not
heavy engineering. Explain architectural trade-offs before implementing them —
do not assume I will catch a bad decision in generated code. If I ask for
something that will cause problems later, say so before building it.

## How I want you to work

**Plan before code.** For anything beyond a small fix, write the approach to
`docs/plans/<slug>.md` first and stop. I read it, correct it, then say go.
Catching a wrong approach in a plan costs minutes; catching it in 800 lines
costs a day.

**One concern per session.** Do not drift into adjacent work. If you spot
something else that needs doing, add it to `docs/BACKLOG.md` and carry on.

**Vertical slices, not layers.** Build one complete user path end to end before
thickening any part of it. Never "build the auth system" then "build the CV
module" — build signup → onboarding → roadmap → dashboard, crude but whole,
then improve it.

**Stop and ask when a decision is load-bearing.** Schema changes, new
dependencies, anything touching the LLM cost model, anything that changes how
the two services talk to each other. Do not decide these silently.

**Say when you are unsure.** If you are guessing at an API's behaviour or a
library's interface, say so and verify rather than producing confident code
built on an assumption.

## Rules that override defaults

- **Migrations are the only way the schema changes.** Never edit tables
  directly, never let an ORM auto-sync in any environment. Schema drift across
  a Node service and a Python service is the failure mode most likely to cost
  me weeks.
- **No secrets in code, ever.** API keys, database URLs, LLM credentials all
  come from environment variables. `.env` is gitignored. If you need a new one,
  add it to `.env.example` with a placeholder and tell me.
- **Every LLM call is cached and logged.** Cache by input hash. Log tokens in,
  tokens out, latency, and cost per call. API spend is a real constraint on this
  project and an unmonitored loop can burn a month's budget in an afternoon.
- **Every LLM call has a timeout, a retry limit, and a fallback.** The UI must
  degrade gracefully, never hang. A roadmap that fails to generate must show the
  user something useful.
- **Never trust LLM output shape.** Validate against a schema before it touches
  the database or the UI. Assume it will occasionally return malformed JSON,
  because it will.
- **Job data is cached, not fetched live per request.** External job APIs rate
  limit aggressively. Fetch on a schedule into our own store; serve from there.
- **Commit at every green point.** Small commits with real messages. This git
  history is my development record for the dissertation, so it needs to read
  like a build, not like a dump.

## Things I do not want

- Do not build an employer-facing portal, a mobile app, payments, or
  qualification verification. All explicitly out of scope in the proposal.
- Do not add a dependency to solve something a few lines of code would handle.
- Do not generate placeholder or lorem-ipsum content in anything I might demo.
  Use realistic South African data — real TVET college names, real job titles,
  real salary ranges in rand.
- Do not silently change scope to something easier. Tell me it is hard.

## Known risks — check `docs/RISKS.md` before assuming any of these are settled

1. **ESSA has no known public API.** It is a login-gated JSF portal requiring an
   SA ID number. The proposal assumes an API exists. This is unverified and
   load-bearing. Fallback is Adzuna, which covers South Africa, has a free
   developer tier, and rate limits hard. Do not architect around ESSA until it
   is confirmed.
2. **LLM cost per roadmap generation is unmeasured.** Until it is, treat every
   design that generates roadmaps in bulk as suspect.
3. **Reliable structured output from the LLM is unproven.** The whole roadmap
   feature depends on it.

## Open decisions — do not assume, ask me

- Monorepo or separate repos for the Node app and the Python ML service
- Whether LLM calls originate in the Node backend or the Python service
- Hosting target

## Domain vocabulary

Use these terms consistently in code, comments and docs. They are the terms in
the dissertation and mismatched naming will cost me later.

- **Roadmap** — the personalised, updating career plan. Not "path" or "plan".
- **Pathway** — a career or trade route in the reference data (e.g. plumbing via
  TVET). The Career Pathway Builder selects pathways and assembles a roadmap.
- **Opportunity** — any job, internship, learnership, certification, workshop or
  event we surface. One concept, one table.
- **Profile** — the user's stored assessment result, not their account.
- **TVET** — Technical and Vocational Education and Training college.
- **SETA** — Sector Education and Training Authority.

## Where to look

- `docs/ROADMAP.md` — the seven project phases, what each contains, and where I
  am now. **Read this at the start of any session where I ask "what's next".**
- `docs/RISKS.md` — open risks and their current status
- `docs/DECISIONS.md` — architecture decisions and why. Append, never rewrite.
- `docs/BACKLOG.md` — things noticed but deliberately deferred
- `docs/plans/` — approach documents awaiting my approval

## Success criteria I am assessed against

Keep these visible when making trade-offs:

1. All seven phases inside plan, submitted by 30 November 2026, within budget
2. All five modules working; zero critical defects at UAT close
3. ≥80% recommendation relevance against a 50-profile benchmark set
4. 20–30 UAT participants, ≥80% rating their roadmap useful and actionable
5. A complete end-to-end journey demonstrated for **both** user profiles, with
   the unqualified-user journey ending in a named institution and real entry
   requirements

Criterion 5 is the one the project is actually judged on. A beautiful platform
that cannot produce that journey has failed.
