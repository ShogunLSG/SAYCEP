# Open Risks

Status values: OPEN / MITIGATED / CLOSED / REALISED

---

## R1 — ESSA may have no public API
**Status:** OPEN
**Impact:** High. The proposal's business-opportunity section and the whole
opportunity matching engine are built on this assumption.
**Evidence:** essa.labour.gov.za is a login-gated JSF application
(/EssaOnline/WebBeans/). Registration requires a valid SA ID number. No
developer portal, no documented endpoints found.
**Mitigation:** Phase 0 spike 1. Fallback is Adzuna (covers South Africa, free
developer tier, rate limits hard — cache on our side).
**If realised:** Update proposal sections 2.2.2 and 2.3. Frame it in the
dissertation as an evaluated-and-rejected option, which is a stronger finding
than an assumption that happened to hold.

## R2 — LLM cost per roadmap generation is unmeasured
**Status:** OPEN
**Impact:** High. Could invalidate the free-to-user model or force a much
cheaper generation strategy.
**Mitigation:** Phase 0 spike 2. Cache by input hash from day one. Log tokens
and cost on every call.

## R3 — Structured LLM output may be unreliable
**Status:** OPEN
**Impact:** High. The roadmap feature depends on parseable, schema-valid output.
**Mitigation:** Phase 0 spike 3. If failure rate is non-trivial, build a
validate-repair-retry layer as a designed component, not a patch.

## R4 — Curated TVET/SETA dataset is manual and blocks Criterion 5
**Status:** OPEN
**Impact:** High. Criterion 5 requires the unqualified-user journey to end in a
named institution with real entry requirements. No dataset, no criterion.
**Mitigation:** Start compiling in Phase 2. Do not defer.

## R5 — UAT participant recruitment
**Status:** OPEN
**Impact:** Medium-high. Needs 20-30 participants across both profiles, on
campus, in October 2026. The window does not move.
**Mitigation:** Begin recruiting during Phase 5.

## R6 — Solo developer, no slack
**Status:** OPEN
**Impact:** Medium. Illness, work pressure, or one bad phase has nowhere to
absorb. Criterion 1 allows 10 working days of overrun per phase.
**Mitigation:** Cut scope rather than slip dates. Flag overruns early.
