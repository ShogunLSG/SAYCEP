# Architecture Decisions

Append only. Never rewrite or delete an entry — a superseded decision stays,
with a new entry explaining what replaced it and why. This log is evidence for
the dissertation.

Format:

## YYYY-MM-DD — <decision>
**Context:** what forced the choice
**Options considered:** what else was on the table
**Decision:** what was chosen
**Consequences:** what this now commits us to, including the downsides

---

## PENDING — Job data source

**Context:** The proposal assumes ESSA exposes a public API. Investigation
suggests it is a login-gated JSF portal requiring an SA ID number, with no
developer portal or documented endpoints.
**Options considered:** ESSA (unverified), Adzuna (SA coverage, free developer
tier, aggressive rate limits), manually seeded dataset.
**Decision:** _Not yet made — Phase 0 spike 1 decides this._
**Consequences:** _TBD_

## PENDING — Monorepo or separate repos

**Context:** Node/React app plus a separate Python ML microservice.
**Decision:** _Not yet made._

## PENDING — Where LLM calls originate

**Context:** Either the Node backend or the Python service owns LLM
integration. Splitting it across both means two cost-tracking paths and two
caching layers.
**Decision:** _Not yet made._
