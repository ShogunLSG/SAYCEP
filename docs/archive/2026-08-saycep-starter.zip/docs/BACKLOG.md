# Backlog

Things noticed mid-session and deliberately deferred. Not a wishlist — only
things that genuinely need doing, so this stays worth reading.

Format: `- [ ] <thing> — noticed <date>, phase <n>, why deferred`

---

